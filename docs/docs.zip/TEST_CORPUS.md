# 測試語料與來源支援清單（TEST_CORPUS）

- 版本：**1.0-draft**；日期：2026-10-15；**待使用者審核（Q-12、Q-21、Q-27）**
- 用途：M1「測試用文章 URL 清單」與「來源支援矩陣」的**初始提案**。相關：[SRS.md](SRS.md) FR-114／115、[ACCEPTANCE_TESTS.md](ACCEPTANCE_TESTS.md) AT-EXT／AT-M1、[ARCHITECTURE.md](ARCHITECTURE.md) §7、§15.2。
- 狀態：**所有「M1 驗收結果」欄位目前為「待測」**——尚未寫任何程式、尚未建立快照與黃金檔。

---

## 1. 觀察方法與限制（務必先讀）

- 2026-10-15，對各網站首頁做一次 GET 取得文章連結，再對每個來源的 1～2 篇文章做**單次 GET**（誠實的研究用 User-Agent「PTTAutoPost-planning-research」；不帶 Cookie、不登入、不繞過任何牆、不執行腳本、未用瀏覽器）。**每個 URL 只請求一次。**
- 觀察內容僅為**結構訊號**（HTTP 狀態、編碼宣告、OpenGraph、JSON-LD 型別、發布時間／作者 meta 是否存在、段落數粗估）。**沒有人工閱讀全文，沒有確認內文是否完整**。「段落數」由簡易規則計算，包含推薦、留言等雜訊，不是正文長度。
- **新聞 URL 會過期**（多為 2026-10-15 的即時新聞），站台也會改版；因此：**M1 的閘門測試使用離線快照**（Phase 1 擷取），線上 URL 僅作線上抽查與快照來源。清單中的 URL 在快照建立前不保證可用。
- 快照涉及第三方內容：僅供本機測試、不隨發行版散布；是否允許保存【待確認】Q-05（**非法律建議**）。
- 這是**取樣**，不代表各站台的一致行為。

---

## 2. 觀察到的跨站規律（對解析器設計的意義）

| 編號 | 觀察（單篇取樣，2026-10-15） | 設計意義 |
|------|------------------------------|----------|
| C-01 | 19 個取樣站全部對一般 GET 回 HTTP 200，編碼宣告皆為 UTF-8；多數為伺服器端渲染且含 OpenGraph | M1 以靜態解析為主可行；但 **Medium、Dcard 回 403**（見 §4.3） |
| C-02 | JSON-LD 文章型節點（NewsArticle／Article）：多數站台有；**ETtoday 的 JSON-LD 為無法解析的壞 JSON**；報導者、iThome、科技新報、PTT 網頁版無 | 必須隔離壞資料、必須有非 JSON-LD 路徑（FR-104） |
| C-03 | **meta `author` 常是機構名而非記者**：中央社（中央通訊社）、自由時報、聯合新聞網、中時、NOWnews、三立皆為機構名；ETtoday、公視、風傳媒、數位時代的 meta author 看似為記者姓名；BBC、科技新報的 author 是社群網址；TVBS、天下、iThome、報導者、Yahoo、PTT 無 author meta | 「作者／記者」需內文署名推定（S4）＋INFERRED 標示＋人工確認；機構名不可直接當記者（媒體來源與記者分欄） |
| C-04 | 發布時間 meta（`article:published_time` 等）：三立、Yahoo、iThome、科技新報、數位時代、天下、PTT 在 meta 層未取得（可能在 JSON-LD、`<time>` 或內文，**待快照確認**）；TVBS 的時間為 UTC（`Z`） | 時間需多路徑取得與時區處理 |
| C-05 | 部分站台連結帶疑似追蹤參數：聯合新聞網 `?from=`、中時 `?ctrack=`、天下 `?rec=`（**用途為推測，待快照／站台說明確認**） | 追蹤參數由站台規則宣告；Canonical 比對須能把加參數與不加參數視為同篇（AT-EXT 重複組） |
| C-06 | 頁面體積差異大：PTT 網頁版約 5–7 KB（純文字 div、無 `<p>`、無 OG type）、iThome 約 51 KB、風傳媒約 1.0–1.2 MB、維基百科文章約 1.0 MB | 抓取上限（5 MB 暫定）夠用但需測邊界；PTT 網頁版需專屬處理（FR-107） |
| C-07 | 前端渲染／登入牆（取樣首頁而非文章）：Facebook 首頁無腳本時可見文字約 270 字元；LINE TODAY 約 725；vocus 首頁約 1,270 且含 `__NEXT_DATA__`；Threads 轉址到 threads.com | 動態網頁偵測（FR-111）需負向與正向測試；vocus 類「內嵌狀態 JSON」可能是可靜態取用的路徑（V-19） |
| C-08 | 報導者的前兩個 `/a/` 連結其實是電子報與 Podcast，**不是一般報導**；關鍵評論網樣本 1 的 author 為「TNL Marketing」、`og:type=website`，疑為廣編稿 | 語料需**人工確認每篇是否為典型文章**；非典型文章另標為邊界案例 |
| C-09 | 所有來源的內文都含大量站內元素（導覽、推薦、留言、廣告、延伸閱讀） | 完整性判定與雜訊率（AT-M1）必須量測，不能以「抓到文字」為成功 |

---

## 3. 候選來源觀察表（首篇取樣）

欄位：HTTP＝回應碼；LD＝是否有 JSON-LD 文章型節點；時間／作者＝meta 層訊號；`—`＝未取得（不等於網頁真的沒有）；「單篇」欄為取樣首篇的結構訊號摘要。

| 代號 | 來源 | 版型類別 | HTTP | LD | 時間 meta | 作者 meta | 備註（觀察＋初判） |
|------|------|----------|------|----|-----------|-----------|--------------------|
| cna | 中央社 | 通訊社 | 200 | ✔ | ✔ | 機構名 | 記者署名預期在內文首段（如「（中央社記者…電）」格式，**待快照確認**） |
| ltn | 自由時報 | 大型入口 | 200 | ✔ | ✔ | 機構名 | 內含「展開」「下一頁」等字樣，**是否有分頁待快照確認** |
| udn | 聯合新聞網 | 大型入口 | 200 | ✔ | ✔ | 機構名 | 連結帶 `?from=`；頁面含「會員」「登入」字樣（待確認是否有付費牆） |
| ettoday | ETtoday | 大型入口 | 200 | ✘（**壞 JSON-LD**） | ✔ | 記者姓名（疑） | 壞 JSON-LD 測試案例 |
| chinatimes | 中時新聞網 | 大型入口 | 200 | ✔（Article） | ✔ | 機構名 | 連結帶 `?ctrack=`；首篇段落數偏少（7 段），**需判斷是短訊或不完整** |
| tvbs | TVBS | 電視新聞 | 200 | ✔ | ✔（UTC） | — | 36 段落（含雜訊） |
| setn | 三立新聞 | 電視新聞 | 200 | ✔ | — | 機構名 | 發布時間可能在 LD |
| pts | 公視 PNN | 公共媒體 | 200 | ✔ | ✔ | 記者姓名（疑） | LD 含 FAQPage 等多型別（Organization／非文章節點干擾案例） |
| storm | 風傳媒 | 網路原生 | 200 | ✔ | ✔ | 記者姓名（疑） | 頁面極大（≈1.0–1.2 MB） |
| nownews | NOWnews | 大型入口 | 200 | ✔ | ✔ | 機構名 | — |
| bbc | BBC 中文（繁） | 國際媒體 | 200 | ✔ | ✔ | 社群網址 | 含 `__NEXT_DATA__`（內嵌狀態 JSON 案例）；author 為 URL，需排除 |
| ptt | PTT 網頁版（Test 板） | 論壇 | 200 | ✘ | — | — | 純文字 `div`、無 `<p>`；metaline（作者／標題／時間）在特定結構；推文需排除；樣本為測試貼文，內容極短 |
| twreporter | 報導者 | 深度報導 | 200 | ✘ | ✔ | — | 兩個首頁樣本為電子報／Podcast（非典型，見 C-08）；需另找一般報導 |
| newslens | 關鍵評論網 | 網路原生 | 200 | ✔ | ✔ | 疑廣編 | 樣本 1 疑為廣編稿；需另找一般文章 |
| ithome | iThome | 科技媒體 | 200 | ✘ | — | — | 頁面小（≈51 KB）；有 `<article>` |
| technews | 科技新報 | 科技媒體 | 200 | ✘ | — | 社群網址 | — |
| bnext | 數位時代 | 財經科技 | 200 | ✔ | — | 記者姓名（疑） | 頁面含「付費」字樣，**待確認是否有付費牆／會員內容** |
| cw | 天下雜誌 | 財經雜誌 | 200 | ✔ | — | — | 頁面含「訂閱」「會員」字樣，**付費牆風險高，待確認** |
| yahoo | Yahoo 奇摩新聞 | 聚合／轉載 | 200 | ✔ | — | — | 轉載型頁面；URL 含中文 slug（percent-encoding 案例）；頁面大（≈760 KB） |
| wiki | 維基百科（臺北市條目） | 百科 | 200 | 未分析 | 未分析 | — | 長文、表格、參考資料、infobox；僅確認 200 與體積（≈1.0 MB） |

---

## 4. 來源支援矩陣（初始提案；M1 閘門以此為基準）

**欄位目標說明**：T＝標題、S＝媒體來源、U＝原文 URL、A＝作者／記者、D＝發布時間、B＝內文（全文）。「✔」＝要求取得；「△」＝允許未取得但須明確標示；「推」＝允許由內文署名推定（INFERRED，須人工確認）。
**所有「驗收結果」均為「待測」；「規則版本」「最後驗證」待 Phase 3 填入。**

### 4.1 Tier A（M1 閘門；≥ 2 篇快照全文黃金比對）

| 來源 | T | S | U | A | D | B | 已知／預期特性 | 驗收結果 | 規則版本 | 最後驗證 |
|------|---|---|---|---|---|---|----------------|----------|----------|----------|
| 中央社 cna | ✔ | ✔ | ✔ | 推 | ✔ | ✔ | meta author 為機構；記者在內文 | 待測 | — | — |
| 自由時報 ltn | ✔ | ✔ | ✔ | 推 | ✔ | ✔ | 可能有分頁（待確認） | 待測 | — | — |
| 聯合新聞網 udn | ✔ | ✔ | ✔ | 推 | ✔ | ✔ | 追蹤參數；會員字樣 | 待測 | — | — |
| ETtoday | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | 壞 JSON-LD 需隔離 | 待測 | — | — |
| 中時 chinatimes | ✔ | ✔ | ✔ | 推 | ✔ | ✔ | 短訊 vs 不完整判定 | 待測 | — | — |
| TVBS | ✔ | ✔ | ✔ | △ | ✔ | ✔ | 時間為 UTC；無作者 meta | 待測 | — | — |
| 三立 setn | ✔ | ✔ | ✔ | 推 | ✔ | ✔ | 時間在 LD 或他處（待確認） | 待測 | — | — |
| 公視 PNN pts | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | LD 多型別干擾 | 待測 | — | — |
| 風傳媒 storm | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | 超大頁面效能 | 待測 | — | — |
| NOWnews | ✔ | ✔ | ✔ | 推 | ✔ | ✔ | meta author 為機構 | 待測 | — | — |
| BBC 中文 bbc | ✔ | ✔ | ✔ | △ | ✔ | ✔ | `__NEXT_DATA__`；author 為 URL | 待測 | — | — |
| PTT 網頁版 ptt | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | 無 `<p>`；metaline；推文排除 | 待測 | — | — |

### 4.2 Tier B（部分支援；≥ 1 篇快照；欄位狀態與警告必須正確）

| 來源 | 期望 | 已知／預期特性 | 驗收結果 |
|------|------|----------------|----------|
| 報導者 twreporter | T／U／B；A、D 視站台 | 需先找典型報導；長文 | 待測 |
| 關鍵評論網 newslens | T／U；B 視版型 | 廣編稿辨識（作者 TNL Marketing） | 待測 |
| iThome | T／U／B | 無 LD、無 meta 時間 | 待測 |
| 科技新報 technews | T／U／B | author 為社群網址須排除 | 待測 |
| 數位時代 bnext | T／U／B／A | 可能有付費內容 → 完整性警告 | 待測 |
| 天下 cw | T／U；B 可能部分 | 付費牆 → 必須警告「疑似不完整」 | 待測 |
| Yahoo 新聞 yahoo | T／U；B 視轉載型態 | 中文 slug；轉載同新聞 → 重複偵測案例 | 待測 |
| 維基百科 wiki | T／U／B | 長文、表格、參考資料雜訊；無「記者」 | 待測 |

### 4.3 Tier C（優雅失敗；必須說明原因、不繞過、引導手動輸入）

| 來源／情境 | 觀察 | 期望結果 | 驗收結果 |
|-------------|------|----------|----------|
| Medium | 一般 GET 回 **403**（5,433 bytes 挑戰頁） | `BLOCKED`＋原因；不重試、不偽裝 UA | 待測 |
| Dcard | 一般 GET 回 **403**（5,016 bytes） | 同上 | 待測 |
| Facebook／Instagram／Threads | 前端渲染／登入牆；首頁無腳本可見文字極少（Facebook ≈270 字元）；Threads 轉址至 threads.com | `NEEDS_JS`／`LOGIN_REQUIRED` | 待測（需使用者提供貼文 URL，Q-27） |
| LINE TODAY、vocus | 前端渲染外殼（可見文字 ≈725／1,270），含內嵌狀態 JSON | 嘗試靜態內嵌 JSON；否則 `NEEDS_JS` | 待測（需文章 URL；現僅有首頁樣本） |

### 4.4 使用者來源（待使用者提供）
Q-27：請提供**你實際會轉貼的來源與真實文章 URL（至少 12 個來源）**。以此修正 Tier A 清單；上述初始提案僅依台灣主流媒體取樣，**未必符合你的實際使用情境**。

---

## 5. 測試語料清單

### 5.1 真實網站快照（Phase 1 擷取；僅本機測試）

每個 Tier A 來源 ≥ 2 篇、Tier B ≥ 1 篇。下列 URL 皆於 2026-10-15 對**首頁**取得連結後**確認可 GET（HTTP 200）**；**未經人工確認其為典型文章**，快照時需檢視並可替換。ID 規則：`S-<代號>-<序號>`。

| ID | URL（已移除疑似追蹤參數） |
|----|----------------------------|
| S-cna-01 | https://www.cna.com.tw/news/aipl/202609045002.aspx |
| S-cna-02 | https://www.cna.com.tw/news/aloc/202610150202.aspx |
| S-ltn-01 | https://news.ltn.com.tw/news/life/breakingnews/5607412 |
| S-ltn-02 | https://news.ltn.com.tw/news/politics/breakingnews/5607344 |
| S-udn-01 | https://udn.com/news/story/6811/9816746 |
| S-udn-02 | https://udn.com/news/story/7315/9816953 |
| S-ettoday-01 | https://www.ettoday.net/news/20261015/3255218.htm |
| S-ettoday-02 | https://www.ettoday.net/news/20261015/3255237.htm |
| S-chinatimes-01 | https://www.chinatimes.com/realtimenews/20261015002904-260410 |
| S-chinatimes-02 | https://www.chinatimes.com/realtimenews/20261015002697-260410 |
| S-tvbs-01 | https://news.tvbs.com.tw/politics/4036502 |
| S-tvbs-02 | https://news.tvbs.com.tw/local/4036526 |
| S-setn-01 | https://www.setn.com/news/1923085 |
| S-setn-02 | https://www.setn.com/news/1923099 |
| S-pts-01 | https://news.pts.org.tw/article/831468 |
| S-pts-02 | https://news.pts.org.tw/article/831467 |
| S-storm-01 | https://www.storm.mg/article/11172736 |
| S-storm-02 | https://www.storm.mg/article/11172645 |
| S-nownews-01 | https://www.nownews.com/news/6883719 |
| S-nownews-02 | https://www.nownews.com/news/6883713 |
| S-bbc-01 | https://www.bbc.com/zhongwen/articles/c674pq1e0dxqo/trad |
| S-bbc-02 | https://www.bbc.com/zhongwen/articles/cjkge2k03kgpo/trad |
| S-ptt-01 | https://www.ptt.cc/bbs/Test/M.1792029688.A.149.html |
| S-ptt-02 | https://www.ptt.cc/bbs/Test/M.1792031562.A.11D.html |
| S-twreporter-01 | https://www.twreporter.org/a/hello-world-2026-10-15 （**電子報，非典型**；需另補一般報導） |
| S-twreporter-02 | https://www.twreporter.org/a/podcast-2026-10-14 （**Podcast，非典型**） |
| S-newslens-01 | https://www.thenewslens.com/article/256582 （**疑廣編稿**） |
| S-newslens-02 | https://www.thenewslens.com/article/270582 |
| S-ithome-01 | https://www.ithome.com.tw/news/179572 |
| S-ithome-02 | https://www.ithome.com.tw/news/179574 |
| S-technews-01 | https://technews.tw/2026/10/15/tsmc-will-begin-adopting-high-na-euv-in-2030/ |
| S-technews-02 | https://technews.tw/2026/10/15/tsmc-ai-demand-is-booming/ |
| S-bnext-01 | https://www.bnext.com.tw/article/92628/tsmc-q3-2026-earnings-preview |
| S-bnext-02 | https://www.bnext.com.tw/article/92631/2026-delta-sst-energy-taiwan |
| S-cw-01 | https://www.cw.com.tw/article/5143032 |
| S-cw-02 | https://www.cw.com.tw/article/5143233 |
| S-yahoo-01 | https://tw.news.yahoo.com/2026%E4%B9%9D%E5%90%88%E4%B8%80%E9%81%B8%E8%88%89-22%E7%B8%A3%E5%B8%82%E9%95%B7%E5%80%99%E9%81%B8%E4%BA%BA%E5%AE%8C%E6%95%B4%E5%90%8D%E5%96%AE%E4%B8%80%E6%AC%A1%E7%9C%8B-060431831.html |
| S-wiki-01 | https://zh.wikipedia.org/wiki/%E8%87%BA%E5%8C%97%E5%B8%82 |
| S-medium-01 | https://medium.com/ （403 探針；需補文章 URL） |
| S-dcard-01 | https://www.dcard.tw/f/trending （403 探針；需補文章 URL） |
| S-fb-01 | https://www.facebook.com/ （登入牆／前端渲染探針；需補貼文 URL，Q-27） |
| S-line-01 | https://today.line.me/tw/v3/tab （前端渲染探針；需補文章 URL） |
| S-vocus-01 | https://vocus.cc/ （前端渲染＋內嵌 JSON 探針；需補文章 URL） |

> 重複偵測用的**追蹤參數變體**不另存快照：由 S-udn-01 加 `?from=redpush`、S-chinatimes-01 加 `?ctrack=mo_main_alert_p01`、S-cw-01 加 `?rec=es` 構成（這些參數是在各站台首頁連結上觀察到的），測試時以字串組合產生。

### 5.2 合成夾具（補足真實網站難以取得或不穩定的情境）

合成夾具由我們自行撰寫（不含第三方內容），確保**可重複、可版本控管**。ID 規則：`X-<序號>`。情境標籤：LAYOUT 版型、DYN 動態、FAIL 失敗、MISS 缺欄位、ENC 中文編碼、DUP 重複、PART 內文不完整、SAFE 安全／雜訊。

| ID | 標籤 | 內容 | 預期 |
|----|------|------|------|
| X-01 | ENC | Big5 編碼頁面（標頭宣告 big5） | 正確解碼；`charset_used=big5`；中文無亂碼 |
| X-02 | ENC | GBK／簡體頁面 | 正確解碼；提示為簡體（編碼檢查將於組稿時阻擋不可編碼字元） |
| X-03 | ENC | UTF-8 含 BOM；無標頭宣告、僅 BOM | 以 BOM 判定 |
| X-04 | ENC | 標頭宣告 UTF-8，meta 宣告 big5（互相矛盾） | 依優先序採標頭；不被自動偵測覆蓋 |
| X-05 | ENC | 未宣告編碼的 Big5 頁面 | 走自動偵測；警告「編碼為偵測結果」 |
| X-06 | ENC | 內文含 emoji、罕用字、全形標點 | 解析保留；組稿檢查階段標示不可編碼 |
| X-07 | LAYOUT | 標準新聞（JSON-LD＋OG＋`<article>`） | 全欄位 FOUND，來源策略為 JSON-LD／規則 |
| X-08 | LAYOUT | JSON-LD 為 `@graph`，Organization 在 NewsArticle 之前 | 標題／作者取自 NewsArticle，不取 Organization |
| X-09 | MISS | JSON-LD 為壞 JSON | 隔離；降級到 OG／通用；警告 |
| X-10 | MISS | 無作者 meta；作者只在內文首段「記者○○／台北報導」 | A 為 INFERRED；信心較低；可人工確認 |
| X-11 | MISS | meta author 為機構名（媒體名） | 不當作記者；A＝未取得或推定自內文 |
| X-12 | MISS | meta author 為社群網址 | 排除；A＝未取得 |
| X-13 | MISS | 無發布時間 | D＝未取得（明確標示） |
| X-14 | MISS | 無標題（無 h1／og:title／title） | T＝未取得；整體 PARTIAL |
| X-15 | LAYOUT | 純 `div` 文字、無 `<p>`（類 PTT 網頁版） | 內文保留換行 |
| X-16 | LAYOUT | 巢狀 `div` 內含 `p`（易重複段落） | 無重複段落 |
| X-17 | SAFE | 內文夾雜「延伸閱讀／相關新聞／責任編輯／廣告」 | 移除或標記；雜訊率達標 |
| X-18 | SAFE | 內文含 ESC 序列、控制字元、零寬字元 | 解析保留原文；正規化階段產生差異報告 |
| X-19 | DYN | 前端渲染外殼：`<div id=root>`＋`noscript` 提示 | `CSR_SHELL`／`NEEDS_JS`；不假成功 |
| X-20 | DYN | 外殼但內嵌狀態 JSON 含完整文章 | 靜態取得；來源策略標「內嵌狀態」 |
| X-21 | FAIL | HTTP 403 挑戰頁 | `BLOCKED`；不重試；引導手動 |
| X-22 | FAIL | 登入牆／年齡確認頁 | `LOGIN_REQUIRED`／相應原因 |
| X-23 | FAIL | HTTP 404／500／逾時／連線拒絕 | 對應錯誤碼；保存 FAILED Article |
| X-24 | FAIL | 非 HTML（PDF／圖片） | 拒絕並說明 |
| X-25 | FAIL | 重新導向過多／循環／導向非 HTTP(S) | 達上限即停止並說明 |
| X-26 | FAIL | 超過大小上限（>5 MB） | 中止並說明 |
| X-27 | FAIL | 畸形 URL 清單（不完整 IPv6、`javascript:`、`file:`、空字串、含 userinfo） | 驗證失敗或警告；不拋未處理例外 |
| X-28 | PART | 內文被截斷：結尾為「展開全文／繼續閱讀」 | `SUSPECT_PARTIAL`＋原因 |
| X-29 | PART | 付費牆：僅前 2 段＋訂閱提示 | `SUSPECT_PARTIAL`／`INSUFFICIENT`；不得顯示為成功 |
| X-30 | PART | 分頁文章（`rel=next`、「第 1/3 頁」） | `SUSPECT_PARTIAL`＋頁數；M1 不自動抓後續頁 |
| X-31 | PART | 標題與連結齊全但內文為空／過短 | `INSUFFICIENT`；整體 PARTIAL（**不得計為成功**） |
| X-32 | PART | 候選區塊其實是推薦清單（連結密度高） | 不採用；落到下一策略或 INSUFFICIENT |
| X-33 | DUP | 同一文章加／不加追蹤參數、大小寫與 query 順序不同 | Canonical 相同；匯入時警告重複 |
| X-34 | DUP | 同一內容在不同網域轉載（標題略異） | 內容指紋／相似度警告；不得僅憑標題判定 |
| X-35 | DUP | 僅標題相同、內容不同 | **不得**判定為重複 |
| X-36 | DUP | 同一 Article 建立第二份草稿／加入其他看板 | 額外警告 |
| X-37 | LAYOUT | 站台規則網域匹配：`example.com` 與 `www.example.com`、`notexample.com` | 前兩者匹配、後者不匹配 |
| X-38 | MISS | 站台規則檔損壞（YAML 語法錯、型別錯、選擇器錯） | 只停用該規則並報告；其餘規則正常；回退通用解析 |
| X-39 | LAYOUT | 規則存在但頁面版型已變（選擇器全數落空） | 回退下一策略；警告「站台規則可能失效」 |
| X-40 | PERF | 約 1 MB 的長文頁面、深層巢狀 | 在效能預算內完成（NFR-02 門檻【待驗證】） |

### 5.3 真實樣本的缺口（誠實清單）

以下情境目前**沒有已確認的真實網站樣本**，Phase 3 需蒐集或以合成夾具暫代，並在 M1 報告標示：
1. **非 UTF-8（Big5）的真實網站頁面**（V-22）：目前只有合成夾具（X-01～X-05）。
2. **真實付費牆／截斷／分頁文章**：天下、數位時代、聯合新聞網、自由時報**疑似**有，但未確認；需蒐集已確認案例。
3. **真實動態網頁的文章頁**（非首頁）。
4. **真實轉載重複案例**（同新聞跨站）。
5. **圖輯／影音／直播型文章頁**（內文結構特殊）。
6. 使用者實際使用的來源（Q-27）。

---

## 6. 語料維護與回歸流程

1. **蒐集快照**：由語料工具（Phase 1.6）以誠實 UA、遵守間隔，對清單 URL 各 GET 一次，保存原始位元組、回應標頭、最終 URL、擷取時間。
2. **建立黃金檔**：由開發者半自動產生欄位與內文草稿 → **人工逐段核對**（Q-24：使用者全數或抽核）→ 標註每篇的 `typical`（是否典型文章）、`body_expected`（`complete`／`partial`）與預期 `body_status`。
3. **執行回歸**：離線、不連網；輸出每來源×快照×欄位結果；黃金內文以段落召回率與雜訊率評估（門檻 Q-23）。
4. **更新矩陣**：回歸報告 → 來源支援矩陣（§4）；記錄規則版本與最後驗證日期。
5. **線上抽查**（預警，非閘門）：對清單 URL 重新 GET 並與最近快照比對結構訊號；異常→標記該站規則「疑似失效」。
6. **新增來源**：依 IMPLEMENTATION_PLAN §4.2 的 SOP。
7. **版本控管**：快照與黃金檔進 `tests/corpus`；快照內第三方內容僅限本機測試，不散布（Q-05）。

### 6.1 manifest 結構（示意）

```yaml
# tests/corpus/manifest.yaml（示意；實際 schema 於 Phase 1.6 定案）
- id: S-ettoday-01
  source: ettoday
  tier: A
  url: https://www.ettoday.net/news/20261015/3255218.htm
  snapshot: snapshots/ettoday/S-ettoday-01/        # response.bin / headers.json / meta.json
  golden:   golden/ettoday/S-ettoday-01/           # expected.json / body.txt
  tags: [LAYOUT, MISS]                             # 壞 JSON-LD
  typical: true
  expected:
    page_class: ARTICLE
    fetch_status: SUCCESS
    body_status: COMPLETE_LIKELY
    fields: { title: FOUND, site_name: FOUND, source_url: FOUND, author: FOUND, published_at: FOUND, body: FOUND }
  captured_on: 2026-10-15   # 實際值於擷取時填入
```

---

## 7. 待使用者協助

| 項目 | 內容 |
|------|------|
| Q-27 | 提供你實際會轉貼的來源與真實文章 URL（≥ 12 來源）；包含你遇過解析困難的網站 |
| Q-21 | 確認或調整 Tier A／B／C 清單 |
| Q-05 | 是否同意在本機保存第三方頁面快照供測試（不散布） |
| Q-24 | 黃金檔核對方式（全數或抽核） |
